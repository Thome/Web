create table cursos1
(
	codcurso varchar(3) not null,
	nomecurso varchar(30) not null
);

create table disciplinas1
(
	coddisc varchar(8) not null,
	nomedisc varchar(30) not null,
	numcred varchar(2) not null,
	prereq1 varchar(8),
	prereq2 varchar(8)
);

create table curriculos
(
	codcurso varchar(3) not null,
	periodonum varchar(2) not null,
	coddisc varchar(8) not null,
	tipodisc varchar(1) not null
);

insert into cursos1 values
('101','Ciência da Computação'),
('102','Engenharia da Computação');

#primeiro periodo 
insert into disciplinas1 values
('MAT0064','Cálculo 1','06',null,null),
('MAT0067','Vetores e Geometria Analítica','04',null,null),
('COMP0197','Programação Imperativa','04',null,null),
('COMP0196','Fundamentos da Computação','02',null,null),
('MAT0104','Fundamentos da Matemática','06',null,null),
('ENCI0105','Desenho Técnico','04',null,null),
('COMP0206','Fundamentos de Eng. Computação','02',null,null);

#segundo periodo 
insert into disciplinas1 values
('MAT0065','Cálculo 2','06','MAT0064',null),
('COMP0219','Circuitos Digitais','04','COMP0196',null),
('COMP0212','Estrutura de Dados 1','04','COMP0197',null),
('COMP0233','Lógica para Computação','04','MAT0104',null),
('COMP0198','Programação Orientada a Objeto','04','COMP0197',null),
('FISI0260','Física A','04','MAT0064','MAT0067'),
('ENCI0075','Resistência dos Materiais','04','MAT0064','MAT0067'),
('LETR0429','Inglês Instrumental','04',null,null);

#terceiro periodo
insert into disciplinas1 values
('MAT0078','Álgebra Linear','04','MAT0067',null),
('COMP0199','Programação Declarativa','04','COMP0212','COMP0198'),
('COMP0200','Programação Web','02','COMP0198',null),
('FISI0261','Laboratório Física A','02','FISI0260',null),
('COMP0213','Estrutura de Dados 2','04','COMP0212',null),
('COMP0216','Estrutura de Dados para EC'),'06','COMP0197',null),
('MAT0066','Cálculo 3','04','MAT0065',null),
('MAT0069','Equações Diferenciais','06','MAT0065',null);

insert into curriculos values
('101','01','MAT0064','C'),
('101','01','MAT0067','C'),
('101','01','COMP0197','C'),
('101','01','COMP0196','C'),
('101','01','MAT0104','C'),
('101','02','MAT0065','C'),
('101','02','COMP0219','C'),
('101','02','COMP0212','C'),
('101','02','COMP0233','C'),
('101','02','COMP0198','C'),
('101','02','FISI0260','C'),
('101','03','MAT0078','C'),
('101','03','COMP0199','C'),
('101','03','COMP0200','O'),
('101','03','FISI0261','O'),
('101','03','COMP0213','C');

insert into curriculos values
('102','01','MAT0064','C'),
('102','01','MAT0067','C'),
('102','01','COMP0197','C'),
('102','01','ENCI0105','C'),
('102','01','MAT0104','C'),
('102','01','COMP0206','C'),
('102','02','MAT0065','C'),
('102','02','MAT0078','C'),
('102','02','ENCI0075','C'),
('102','02','LETR0429','C'),
('102','02','COMP0198','C'),
('102','02','FISI0260','C'),
('102','02','FISI0261','C'),
('102','03','COMP0199','O'),
('102','03','COMP0200','O'),
('102','03','COMP0216','C'),
('102','03','MAT0066','C'),
('102','03','MAT0069','C');