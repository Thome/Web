package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static web.DisciplinaServlet.DATABASE_URL;

@WebServlet(name = "ListaGradeServlet", urlPatterns = {"/ListaGradeServlet"})
public class ListaGradeServlet extends HttpServlet {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:postgresql://localhost/postgres";
    static final String usuario = "postgres";
    static final String senha = "thome";
    
    protected String aux(String str){
        if (str == null) return "";
        else return str;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        Connection conn;
        String LGtipo = request.getParameter("tipoLG");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>DisciplinaServlet</title>");
        /*out.println("<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>");
        out.print("<link rel=\"stylesheet\" href=\"styleTable.css\" type=\"text/css\">");
        out.println("<style type=\"text/css\">" +
            "<!-- " +
            "body {background-image:url(http://eppora.com/wp-content/uploads/2015/05/plain-light-color-for-guest-background.jpg);"
                + "background-repeat: no-repeat; background-size: cover;"
                + " color:black; font-size:90%}"+
            
            "//--></style>");*/
        out.println("<link href=\"css/bootstrap.css\" rel=\"stylesheet\">");
        out.println("</head>");
        out.println("<body class=\"bg-light\" >");
        
        //navbar: logo listagrade 
        out.println("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">"
                + "<a class=\"navbar-brand\" href=\"#\">"
                + "<img src='logo.png' width='30' height='50' alt=''></a>"
                + "<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" "
                + "data-target=\"#navbarNav\" aria-controls=\"navbarNav\" aria-expanded=\"false\" "
                + "aria-label=\"Toggle navigation\"><span class=\"navbar-toggler-icon\"></span>"
                + "</button><div class=\"collapse navbar-collapse\" id=\"navbarNav\">"
                + "<ul class=\"navbar-nav\">");
        
        //index
        out.println("<li class=\"nav-item\">"
                + "<form action=\"RedirectServlet\">"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Home' name='tipo' /></form></li>");
        
        //listagrade btn
        out.println("<li class=\"nav-item active\">"
                + "<form><input type='hidden' value='' name='tipoLG' />"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Grade Curricular' name='tipo' /></form></li>");
        
        //curriculo btn
        out.println("<li class=\"nav-item\">"
                + "<form action=\"CurriculoServlet\">"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Tabela de Curriculos' name='tipo' /></form></li>");
        
        //disc btn
        out.println("<li class=\"nav-item\">"
                + "<form action=\"DisciplinaServlet\"><input class='btn btn-primary' "
                + "type='submit' value='Tabela de Disciplinas' name='tipo' /></form></li>");
        out.println("</ul></div></nav>");
        
        out.println("<div class=\"container-fluid mb-4\">"
                + "<center><h2>Grade Curricular</h2></center></div>");
        
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(DATABASE_URL, usuario, senha);
            Statement st = conn.createStatement();
            st.executeUpdate("set search_path to matriculas");
            
            ResultSet rec = st.executeQuery(
                    "select * from cursos1");
            
            out.println("<form class=\"form-inline\"><div class=\"form-group ml-2\">");
            out.println("<select class=\"form-control\" name=\"opCurso\">");
            while(rec.next()){
                out.println("<option value=\""+rec.getString(1)+"\">"
                        +rec.getString(2)+"</option>");
            }
            out.println("</select><input type='hidden' name='tipoLG' value='exibe'>");
            out.println("<input class='btn btn-primary' type=\"submit\"></div></form>");
            
            if ("".equals(LGtipo)) {
                //chamado por index
            } else if ("exibe".equals(LGtipo)){
                //chamado por redirect
                String codcurso = request.getParameter("opCurso");
                ResultSet rec2 = st.executeQuery("select nomecurso from cursos1"
                        + " where codcurso='"+codcurso+"'");
                while(rec2.next())
                    out.println("<div class=\"ml-3\"><h2>Grade do curso de "+rec2.getString(1)+"</h2></div>");
                
                ResultSet rec1 = st.executeQuery(
                        "select * " +
                        "from curriculos cr " +
                        "join disciplinas1 ds on cr.coddisc = ds.coddisc " +
                        "where cr.codcurso ='"+codcurso+"' " +
                        "order by periodonum");
                
                out.println("<div class=\"container-fluid\">");
                
                out.println("<table align=\"center\" class = \"table table-striped\">"
                        + "<thead><tr>");
                    out.println("<th scope=\"col\"><b>Período do curso</b></th>"
                        +"<th scope=\"col\"><b>Código da disciplina</b></th>"
                        +"<th scope=\"col\"><b>Nome da disciplina</b></th>"
                        +"<th scope=\"col\"><b>Número de créditos</b></th>"
                        +"<th scope=\"col\"><b>Pré-requisito 1</b></th>"
                        +"<th scope=\"col\"><b>Pré-requisito 2</b></th>"
                        +"<th scope=\"col\"><b>Tipo da Disciplina</b></th>"
                        +"<th scope=\"col\"><b>Alterar</b></th>"
                        +"<th scope=\"col\"><b>Excluir</b></th>"
                        +"</tr></thead><tbody>");
                
                while(rec1.next()){
                    out.println("<tr><td>"+rec1.getString(2)+"</td>");
                    out.println("<td>"+rec1.getString(3)+"</td>");
                    out.println("<td>"+rec1.getString(6)+"</td>");
                    out.println("<td>"+rec1.getString(7)+"</td>");
                    out.println("<td>"+aux(rec1.getString(8))+"</td>");
                    out.println("<td>"+aux(rec1.getString(9))+"</td>");
                    out.println("<td>"+rec1.getString(4)+"</td>");
                    out.println("<td><form action=\"AlterarCurriculo\">"
                            + "<input type='hidden' name='cursoId' value=\""
                            + codcurso + "\">"
                            + "<input type='hidden' name='discId' value=\""
                            + rec1.getString(3) +"\">"+
                            "<input class='btn btn-success' "
                            +"type='submit' value='Alterar' name='send' /></form></td>");
                    out.println("<td><form action=\"RedirectServlet\">"
                        +"<input type='hidden' name='cursoId' value = \""
                                + codcurso + "\">"
                        +"<input type='hidden' name='discId' value = \""
                                + rec1.getString(3) + "\">"
                        +"<input type='hidden' name='tipo' value='E3'>"
                        +"<input class='btn btn-danger' "
                        +"type='submit' value='Excluir' name='enviar' />"
                        +"</form></td></tr>");
                }
                out.println("</tbody></table></div>");
            }
            
            out.println("<footer class=\"section section-primary\">"
                + "<div class=\"container-fluid mb-2\">"
                + "<center>"
                + "<p>Desenvolvido por Thomé Pereira Alves Neto</p>"
                + "</center></div></footer>");            
            
            out.println("</body>");
            out.println("</html>");
        } catch (SQLException s) {
                out.println("SQL Error: " + s.toString() + " "
                    + s.getErrorCode() + " " + s.getSQLState()); 
        } catch (Exception e) {
                out.println("Error: " + e.toString()
                    + e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
