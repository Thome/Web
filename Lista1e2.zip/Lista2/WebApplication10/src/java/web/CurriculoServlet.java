/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static web.DisciplinaServlet.DATABASE_URL;

/**
 *
 * @author user
 */
@WebServlet(name = "CurriculoServlet", urlPatterns = {"/CurriculoServlet"})
public class CurriculoServlet extends HttpServlet {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:postgresql://localhost/postgres";
    static final String usuario = "postgres";
    static final String senha = "thome";
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        Connection conn;
        out.println("<html>");
        out.println("<head>");
        out.println("<title>CurriculoServlet</title>");
        out.println("<link href=\"css/bootstrap.css\" rel=\"stylesheet\">");
        out.println("</head>");
        out.println("<body class=\"bg-light\" >");
        
        //navbar: logo listagrade 
        out.println("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">"
                + "<a class=\"navbar-brand\" href=\"#\">"
                + "<img src='logo.png' width='30' height='50' alt=''></a>"
                + "<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" "
                + "data-target=\"#navbarNav\" aria-controls=\"navbarNav\" aria-expanded=\"false\" "
                + "aria-label=\"Toggle navigation\"><span class=\"navbar-toggler-icon\"></span>"
                + "</button><div class=\"collapse navbar-collapse\" id=\"navbarNav\">"
                + "<ul class=\"navbar-nav\">");
        
        //index
        out.println("<li class=\"nav-item\">"
                + "<form action=\"RedirectServlet\">"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Home' name='tipo' /></form></li>");
        //listagrade btn
        out.println("<li class=\"nav-item\">"
                + "<form action=\"ListaGradeServlet\">"
                + "<input type='hidden' value='' name='tipoLG' />"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Grade Curricular' name='tipo' /></form></li>");
        //curriculo btn
        out.println("<li class=\"nav-item active\">"
                + "<form>"
                + "<input class='btn btn-primary' "
                + "type='submit' value='Tabela de Curriculos' name='tipo' /></form></li>");
        //disc btn
        out.println("<li class=\"nav-item\">"
                + "<form action=\"DisciplinaServlet\"><input class='btn btn-primary' "
                + "type='submit' value='Tabela de Disciplinas' name='tipo' /></form></li>");
        out.println("</ul></div></nav>");
        
        out.println("<div class=\"container-fluid mb-4\">"
                + "<center><h2>Curriculos Ofertados</h2></center></div>");
        
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(DATABASE_URL, usuario, senha);
            Statement st = conn.createStatement();
            st.executeUpdate("set search_path to matriculas");
            
            ResultSet rec = st.executeQuery(
                    "select * from curriculos "
                   +"order by codcurso, periodonum");
            
            out.println("<div class=\"container-fluid\">");
            
            out.println("<table align=\"center\" class = \"table table-striped\">"
                    + "<thead><tr>");
            out.println("<th scope=\"col\"><b>Código do curso</b></th>"
                    +"<th scope=\"col\"><b>Período do curso</b></th>"
                    +"<th scope=\"col\"><b>Código da disciplina</b></th>"
                    +"<th scope=\"col\"><b>Tipo da Disciplina</b></th>"
                    +"<th scope=\"col\"><b>Alterar</b></th>"
                    + "<th scope=\"col\"><b>Excluir</b></th></tr></thead><tbody>");
            
            while(rec.next()){
                out.println("<tr><td>"+rec.getString(1)+"</td>"
                        +"<td>"+rec.getString(2)+"</td>"
                        +"<td>"+rec.getString(3)+"</td>"
                        +"<td>"+rec.getString(4)+"</td>"
                        +"<td><form action=\"AlterarCurriculo\">"+
                        "<input type='hidden' name='cursoId' value = \""
                            + rec.getString(1) + "\">"+
                        "<input type='hidden' name='discId' value = \""
                            + rec.getString(3) + "\">"+
                        "<input class='btn btn-success' "
                            + "type='submit' value='Alterar' name='send' />"
                            + "</form></td>"
                        +"<td><form action=\"RedirectServlet\">"
                        +"<input type='hidden' name='cursoId' value = \""
                            + rec.getString(1) + "\">"
                        +"<input type='hidden' name='discId' value = \""
                            + rec.getString(3) + "\">"
                        +"<input type='hidden' name='tipo' value='E2'>"
                        +"<input class='btn btn-danger' "
                            + "type='submit' value='Excluir' name='enviar' />"
                        +"</form></td></tr>"
                );
            }
            
            out.println("</tbody></table></div>");
            
            out.println("</br><div class=\"container-fluid mb-2\">");
            
            out.println("<h4>Incluir nova Disciplina em currículo:</h4>");
            out.println("<form action=\"RedirectServlet\">"
                    + "<table align=\"center\" class = \"table table-striped\">"
                    + "<thead><tr>"
                    + "<th><b>Código do curso</b></th>"
                    + "<th><b>Período do curso</b></th>"
                    + "<th><b>Código da disciplina</b></th>"
                    + "<th><b>Tipo da matéria</b></th>"
                    + "<th><b>Inserir</b></th></tr></thead>");
            out.println("<tbody><tr><td>"+"<input type='hidden' name='tipo' value='I2'>"
                    + "<input type=\"text\" name=\"cursoId\"></td>"
                    + "<td><input type=\"text\" name=\"pnum\"></td>"
                    + "<td><input type=\"text\" name=\"discId\"></td>"
                    + "<td><input type=\"text\" name=\"discTipo\"></td>"
                    + "<td><input class='btn btn-success' "
                    + "type='submit' value='Incluir' name='enviar' /></td>"
                    + "</tr></tbody></table></form></div>");
            
            out.println("<footer class=\"section section-primary\">"
                    + "<div class=\"container-fluid mb-2\">"
                    + "<center>"
                    + "<p>Desenvolvido por Thomé Pereira Alves Neto</p>"
                    + "</center></div></footer>");
                        
            out.println("</body>");
            out.println("</html>");
        } catch (SQLException s) {
                out.println("SQL Error: " + s.toString() + " "
                    + s.getErrorCode() + " " + s.getSQLState());    
        } catch (Exception e) {
                out.println("Error: " + e.toString()
                    + e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
