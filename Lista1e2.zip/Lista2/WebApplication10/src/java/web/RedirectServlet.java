/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
@WebServlet(name = "RedirectServlet", urlPatterns = {"/RedirectServlet"})
public class RedirectServlet extends HttpServlet {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:postgresql://localhost/postgres";
    static final String usuario = "postgres";
    static final String senha = "thome";
    
    protected String aux(String str){
        if (str == null) return "";
        else return str;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        String tipo = request.getParameter("tipo");
        Connection conn;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(DATABASE_URL, usuario, senha);
            Statement st = conn.createStatement();
            st.executeUpdate("set search_path to matriculas");
            
            if (tipo.equals("I1")){
                RequestDispatcher rd = request.getRequestDispatcher("/DisciplinaServlet");
                String codDisc = request.getParameter("discId");
                String nomeDisc = request.getParameter("nomeDisc");
                String ncred = request.getParameter("ncred");
                String prereq1 = aux(request.getParameter("prereq1"));
                String prereq2 = aux(request.getParameter("prereq2"));
                if (!"".equals(prereq1)){
                    ResultSet rec1 = st.executeQuery("select coddisc from disciplinas1"
                        + " where coddisc = '"+prereq1+"'");
                    if(!rec1.next()) {
                        rd.forward(request, response);
                    }
                }
                if (!"".equals(prereq2)){
                    ResultSet rec = st.executeQuery("select coddisc from disciplinas1"
                        + " where coddisc = '"+prereq2+"'");
                    if(!rec.next()) {
                        rd.forward(request, response);
                    }
                }
                st.executeUpdate("insert into disciplinas1 values"
                        + "('"+codDisc+"','"+nomeDisc+"','"+ncred+"','"
                        +prereq1+"','"+prereq2+"')");
                rd.forward(request, response);
            }
            
            if (tipo.equals("I2")) {
                RequestDispatcher rd = request.getRequestDispatcher("/CurriculoServlet");
                String cursoId = request.getParameter("cursoId");
                String pnum = request.getParameter("pnum");
                String codDisc = request.getParameter("discId");
                String discTipo = request.getParameter("discTipo");
                st.executeUpdate("insert into curriculos values "
                        + "('"+cursoId+"','"+pnum+"','"+codDisc+"','"+discTipo+"')");
                rd.forward(request, response);
            }
            
            if (tipo.equals("A1")){
                RequestDispatcher rd = request.getRequestDispatcher("/DisciplinaServlet");
                String codDisc = request.getParameter("discId");
                String nomeDisc = request.getParameter("nomeDisc");
                String ncred = request.getParameter("ncred");
                String prereq1 = aux(request.getParameter("prereq1"));
                String prereq2 = aux(request.getParameter("prereq2"));
                if (prereq1 != ""){
                    ResultSet rec1 = st.executeQuery("select coddisc from disciplinas1"
                        + " where coddisc = '"+prereq1+"'");
                    if(!rec1.next()) {
                        rd.forward(request, response);
                    }
                }
                if (prereq2 != ""){
                    ResultSet rec = st.executeQuery("select coddisc from disciplinas1"
                        + " where coddisc = '"+prereq2+"'");
                    if(!rec.next()) {
                        rd.forward(request, response);
                    }
                }
                st.executeUpdate("update disciplinas1 "
                        + "set nomedisc = '"+nomeDisc+"', "
                        + "numcred = '"+ncred+"', "
                        + "prereq1 = '"+prereq1+"', "
                        + "prereq2 = '"+prereq2+"' "
                        + "where coddisc = '"+codDisc+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("A2")) {
                RequestDispatcher rd = request.getRequestDispatcher("/CurriculoServlet");
                String cursoId = request.getParameter("cursoId");
                String pnum = request.getParameter("pnum");
                String codDisc = request.getParameter("discId");
                String discTipo = request.getParameter("discTipo");
                st.executeUpdate("update curriculos "
                        + "set periodonum = '"+pnum+"', "
                        + "tipodisc = '"+discTipo+"' "
                        + "where codcurso = '"+cursoId+"' "
                        + "and coddisc = '"+codDisc+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("A3")) {
                RequestDispatcher rd = request.getRequestDispatcher("/ListaGradeServlet");
                String cursoId = request.getParameter("cursoId");
                String pnum = request.getParameter("pnum");
                String codDisc = request.getParameter("discId");
                String discTipo = request.getParameter("discTipo");
                st.executeUpdate("update curriculos "
                        + "set periodonum = '"+pnum+"', "
                        + "tipodisc = '"+discTipo+"' "
                        + "where codcurso = '"+cursoId+"' "
                        + "and coddisc = '"+codDisc+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("E1")){
                RequestDispatcher rd = request.getRequestDispatcher("/DisciplinaServlet");
                String codDisc = request.getParameter("discId");
                st.executeUpdate("delete from disciplinas1 "
                        + "where coddisc='"+codDisc+"'");
                st.executeUpdate("update disciplinas1 "
                        + "set prereq1='' "
                        + "where prereq1='"+codDisc+"'");
                st.executeUpdate("update disciplinas1 "
                        + "set prereq2='' "
                        + "where prereq2='"+codDisc+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("E2")) {
                RequestDispatcher rd = request.getRequestDispatcher("/CurriculoServlet");
                String cursoId = request.getParameter("cursoId");
                String codDisc = request.getParameter("discId");
                st.executeUpdate("delete from curriculos "
                        + "where coddisc='"+codDisc+"'"
                        + " and codcurso='"+cursoId+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("E3")) {
                RequestDispatcher rd = request.getRequestDispatcher("/ListaGradeServlet");
                String cursoId = request.getParameter("cursoId");
                String codDisc = request.getParameter("discId");
                st.executeUpdate("delete from curriculos "
                        + "where coddisc='"+codDisc+"'"
                        + " and codcurso='"+cursoId+"'");
                rd.forward(request, response);
            }
            
            if (tipo.equals("Home")) {
                String indexurl = "/index.html";
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(indexurl);
                dispatcher.forward(request,response);
            }
                    
        } catch (SQLException s) {
                                   
        } catch (Exception e) {
            
        }
        
        //response.sendRedirect("DisciplinaServlet");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
