/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author user
 */
@WebServlet(name = "NewServlet", urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";        
    static final String DATABASE_URL = "jdbc:postgresql://localhost/postgres";
    static final String usuario = "postgres";
    //static final String senha = "postgres";
    static final String senha = "thome";
    
    protected String aux(String str){
        if (str.equals("-")) return "";
        return str;
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        ArrayList<Turma> lista = new ArrayList<>();
        ArrayList<String> aluno = new ArrayList<>();
        String matricula = request.getParameter("matricula");
        Connection conn;
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Servlet ServletMySql33</title>");
        //out.println("<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\"/>");
        //out.print("<link rel=\"stylesheet\" href=\"styleTable.css\" type=\"text/css\">");
        out.println("<link href=\"css/bootstrap.css\" rel=\"stylesheet\">");
        out.println("<style type=\"text/css\">" +
            "<!-- " +
            "body {background-image:url(http://eppora.com/wp-content/uploads/2015/05/plain-light-color-for-guest-background.jpg);"
                + "background-repeat: no-repeat; background-size: cover;"
                + " color:black; font-size:90%}"+
            
            "//--></style>");
        out.println("</head>");
        out.println("<body>");
        
        out.println("</br><div class=\"container-fluid mb-4\">"
                + "<center><h2>Disciplinas Ofertadas</h2></center></div>");
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(DATABASE_URL, usuario, senha);
            Statement st = conn.createStatement();
            st.executeUpdate("set search_path to matriculas");
            
            ResultSet recAluno = st.executeQuery(
                    "select * from alunos "
                    + "where (matricula='"+matricula+"')");
            while(recAluno.next()){
                aluno.add(recAluno.getString(1));
                aluno.add(recAluno.getString(2));
                aluno.add(recAluno.getString(3));
            }
            ResultSet rec = st.executeQuery(
                    "select * from disciplinas md join turmas mt "
                            + "on md.coddisc = mt.disciplina"
                            + " order by coddisc, codturma");
            
            out.println("<div class=\"container-fluid\">");
            out.println("<table align=\"center\" class = \"table table-striped\"><thead><tr>");
            out.println("<th scope=\"col\"><b>Código da disciplina</b></th>"
                    +"<th scope=\"col\"><b>Nome da disciplina</b></th>"
                    +"<th scope=\"col\"><b>Carga horária semanal</b></th>"
                    +"<th scope=\"col\"><b>Código da turma</b></th>"
                    +"<th scope=\"col\"><b>Horários da turma</b></th>"
                    +"<th scope=\"col\"><b>Selecionar disciplina</b></th></tr></thead><tbody>");
            out.println("<form action=\"SolicitacaoMatricula\"");
            int i = 0;
            while(rec.next()) {
                Turma tur = new Turma();
                tur.setDiscCod(rec.getString(1));
                tur.setDiscNome(rec.getString(2));
                tur.setDiscCarga(rec.getString(3));
                tur.setTurmaCod(rec.getString(5));
                String data = aux(rec.getString(6)) + " "
                        + aux(rec.getString(7)) + " "
                        + aux(rec.getString(8));
                tur.setTurmaHoras(data);
                out.println("<tr><td>"+ tur.getDiscCod() + "</td>"
                        + "<td>"+tur.getDiscNome()+ "</td>"
                        + "<td>"+tur.getDiscCarga()+ "</td>" 
                        + "<td>"+tur.getTurmaCod()+ "</td>" 
                         + "<td>"+tur.getTurmaHoras()+ "</td>"      
                        + "<td><input type=\"checkbox\" name=\"checkbox["
                        + i + "]\" value=" + i + "</td></tr>");
                lista.add(tur);
                i++;
            }
            out.println("</tbody></table></div>");
            out.println("<center><input type='submit' value='Matricular' name='enviar' class='btn btn-success'/></center>");
            st.close();            
        } catch (SQLException s) {
                out.println("SQL Error: " + s.toString() + " "
                    + s.getErrorCode() + " " + s.getSQLState());    
        } catch (Exception e) {
                out.println("Error: " + e.toString()
                    + e.getMessage());
        }
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
        session.setAttribute("list", lista);
        session.setAttribute("aluno", aluno);
        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}